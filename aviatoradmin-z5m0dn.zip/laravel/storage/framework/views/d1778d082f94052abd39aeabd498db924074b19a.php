
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                    <i class="mdi mdi-home"></i>
                </span> Amount setup
            </h3>
        </div>
        <div class="row">
            <div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Settings List</h4>
                        </p>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Setting name</th>
                                    <th>Value</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->category); ?></td>
                                    <td><?php echo e($item->value); ?></td>
                                    <td>
                                        <label class="badge badge-warning" onclick="window.location.href='amount-setup/<?php echo e($item->id); ?>'">Edit</label>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php if(isset($id) && $id != null && $specificdata != null): ?>
                <div class="col-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Amount setup</h4>
                            <form class="forms-sample" id="editamountsetup">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <div class="form-group">
                                    <label for="settingname">Setting Name</label>
                                    <input type="text" class="form-control" id="settingname" name="settingname"
                                        placeholder="Setting Name" value="<?php echo e($specificdata->category); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="value">Value</label>
                                    <input type="text" class="form-control" id="value" name="value"
                                        placeholder="Min. Withdrawal" value="<?php echo e($specificdata->value); ?>">
                                </div>
                                <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $("#editamountsetup").on('submit', function(e) {
            e.preventDefault();
        });
        $("#editamountsetup").validate({
            submitHandler: function(form) {
                apex("POST", "<?php echo e(url('admin/api/editamountsetup')); ?>", new FormData(form), form,
                    "/admin/amount-setup", "#");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558340823/domains/thixpro.in/public_html/aviator/laravel/resources/views/admin/amountsetup.blade.php ENDPATH**/ ?>