<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('include.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('include.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('include.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- main-panel start -->
            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('include.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <?php echo $__env->make('include.admin.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH /home/u558340823/domains/thixpro.in/public_html/doltedaviator/laravel/resources/views/Layout/admindashboard.blade.php ENDPATH**/ ?>