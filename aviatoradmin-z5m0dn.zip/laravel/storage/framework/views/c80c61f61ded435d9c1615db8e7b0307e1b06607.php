
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                    <i class="mdi mdi-home"></i>
                </span> Bank Setup
            </h3>
        </div>
        <div class="row">
            <div class="col-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Bank detail</h4>
                        <form class="forms-sample" id="bankdetail">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="1">
                            <div class="form-group">
                                <label for="bank_name">Bank Name</label>
                                <input type="text" class="form-control" id="bank_name" name="bank_name"
                                    placeholder="Bank Name" value="<?php echo e($bank->bank_name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="account_no">Account No</label>
                                <input type="text" class="form-control" id="account_no" name="account_no"
                                    placeholder="Account No" value="<?php echo e($bank->account_no); ?>">
                            </div>
                            <div class="form-group">
                                <label for="holdername">Account holder name</label>
                                <input type="text" class="form-control" id="holdername" name="holdername"
                                    placeholder="Account holder name" value="<?php echo e($bank->account_holder_name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="ifsccode">IFSC Code</label>
                                <input type="text" class="form-control" id="ifsccode" name="ifsccode"
                                    placeholder="IFSC Code" value="<?php echo e($bank->ifsc_code); ?>">
                            </div>
                            <div class="form-group">
                                <label for="mobile_no">Mobile no</label>
                                <input type="text" class="form-control" id="mobile_no" name="mobile_no"
                                    placeholder="Mobile No." value="<?php echo e($bank->mobile_no); ?>">
                            </div>
                            <div class="form-group">
                                <label for="upi_id">UPI Id</label>
                                <input type="text" class="form-control" id="upi_id" name="upi_id"
                                    placeholder="UPI Id" value="<?php echo e($bank->upi_id); ?>">
                            </div>
                            <div class="form-group">
                                <label for="value">Bar code</label>
                                <input type="file" class="form-control" id="barcode" name="barcode">
                            </div>
                            <?php if($bank->barcode != ''): ?>
                                <img src="<?php echo e($bank->barcode); ?>" alt="" style="width:260px;"> <br>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $("#bankdetail").on('submit', function(e) {
            e.preventDefault();
        });
        $("#bankdetail").validate({
            submitHandler: function(form) {
                apex("POST", "<?php echo e(url('admin/api/bankdetail')); ?>", new FormData(form), form,
                    "/admin/bank-detail", "#");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziolfvwj00it/public_html/ludokingstar.com/laravel/resources/views/admin/bankdetail.blade.php ENDPATH**/ ?>